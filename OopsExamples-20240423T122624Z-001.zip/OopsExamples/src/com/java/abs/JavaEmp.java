package com.java.abs;

public class JavaEmp extends Emp {

	public JavaEmp(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
