package com.java.abs;

public abstract class Mobile {
	abstract void name();
	abstract void type();
	abstract void price();
	
}
