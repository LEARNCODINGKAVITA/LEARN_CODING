package com.java.abs;

public class IPhone extends Mobile {

	@Override
	void name() {
		System.out.println("Name is Iphone...");
	}

	@Override
	void type() {
		System.out.println("Its Iphone 15...");
	}

	@Override
	void price() {
		System.out.println("Its 2000$");
	}

}
