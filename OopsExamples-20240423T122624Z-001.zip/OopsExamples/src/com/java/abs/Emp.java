package com.java.abs;

public abstract class Emp {

	int empno;
	String name;
	double basic;
	double hra, da;
	double tax, pf;
	double gpay, netpay;
	public Emp(int empno, String name, double basic) {
		super();
		this.empno = empno;
		this.name = name;
		this.basic = basic;
	}
	public void calc(Emp employ) {
		employ.hra = employ.basic * 0.03;
		employ.da = employ.basic * 0.15;
		employ.tax = employ.basic * 1.2;
		employ.pf = employ.basic * 0.5;
		employ.gpay = employ.basic + employ.hra + employ.da;
		employ.netpay = employ.gpay - employ.tax - employ.pf;
		
	}
	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", name=" + name + ", basic=" + basic + ", hra=" + hra + ", da=" + da + ", tax="
				+ tax + ", pf=" + pf + ", gpay=" + gpay + ", netpay=" + netpay + "]";
	}
	
	
}
