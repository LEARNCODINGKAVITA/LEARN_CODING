package com.java.abs;

abstract class Training {
	abstract void name();
	abstract void email();
}

class Bhavanya extends Training {

	@Override
	void name() {
		System.out.println("Name is Bhavanya...");
	}

	@Override
	void email() {
		System.out.println("Email is bhavanya@gmail.com");
	}
	
}
class Ramesh extends Training {

	@Override
	void name() {
		System.out.println("Name is Ramesh...");
	}

	@Override
	void email() {
		System.out.println("Email is ramesh@gmail.com");
	}
}

class Rajendra extends Training {

	@Override
	void name() {
		System.out.println("Name is Rajendra");
	}

	@Override
	void email() {
		System.out.println("Email is rajendra@gmail.com");
	}
	
}
public class AbsEx {
	public static void main(String[] args) {
//		Training obj1 = new Bhavanya();
//		Training obj2 = new Ramesh();
//		Training obj3 = new Rajendra();
		Training[] arr = new Training[] {
			new Bhavanya(), new Ramesh(), new Rajendra()	
		};
		
		for (Training training : arr) {
			training.name();
			training.email();
		}
	}
}
