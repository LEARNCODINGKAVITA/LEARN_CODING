package com.java.abs;

public class MainProg {

	public static void main(String[] args) {
		String type = "Iphone";
		MobileFactory factory = new MobileFactory();
		Mobile mobile = factory.showMobileInfo(type);
		mobile.name();
		mobile.price();
		mobile.type();
	}
}
