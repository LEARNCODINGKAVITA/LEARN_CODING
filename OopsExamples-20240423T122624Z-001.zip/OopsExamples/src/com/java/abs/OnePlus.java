package com.java.abs;

public class OnePlus extends Mobile {

	@Override
	void name() {
		System.out.println("Name is One Plus...");
	}

	@Override
	void type() {
		System.out.println("Its Model 12R");
	}

	@Override
	void price() {
		System.out.println("Price is 1000$");
	}

}
