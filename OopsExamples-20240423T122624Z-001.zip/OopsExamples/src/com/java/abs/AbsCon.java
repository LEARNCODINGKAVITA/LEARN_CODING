package com.java.abs;

abstract class Employ {

	int empno;
	String name;
	double basic;

	public Employ(int empno, String name, double basic) {
		this.empno = empno;
		this.name = name;
		this.basic = basic;
	}

	@Override
	public String toString() {
		return "Employ [empno=" + empno + ", name=" + name + ", basic=" + basic + "]";
	}
}

class Venkatesh extends Employ {

	public Venkatesh(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}
	
}

class Madhu extends Employ {

	public Madhu(int empno, String name, double basic) {
		super(empno, name, basic);
	}
	
}
class Naresh extends Employ {

	public Naresh(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}
	
}

public class AbsCon {
	public static void main(String[] args) {
		Employ[] arr = new Employ[] {
				new Madhu(1, "Madhu", 58868),
				new Naresh(2, "Naresh", 90053),
				new Venkatesh(3, "Venkatesh", 85522),
		};
		for (Employ employ : arr) {
			System.out.println(employ);
		}
	}
}
