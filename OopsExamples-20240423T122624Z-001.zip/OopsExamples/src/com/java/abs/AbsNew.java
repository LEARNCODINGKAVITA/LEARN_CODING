package com.java.abs;

abstract class Employee {
	int id;
	String name;

	public Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}
}

class Trainer extends Emp {
	public Trainer(int id, String name) {
		super(id, name);
	}
}

class Trainee extends Emp {
	public Trainee(int id, String name) {
		super(id, name);
	}
}

class Admin extends Emp {

	public Admin(int id, String name) {
		super(id, name);
	}
	
}
public class AbsNew {
	public static void main(String[] args) {
		Emp[] arr = new Emp[] {
			new Trainer(1, "Prasanna"),
			new Trainee(2, "Ramesh"),
			new Trainee(3, "Prathyusha"),
			new Trainee(4, "Venkatesh"),
			new Trainee(5, "Shiva Sai Reddy"),
			new Admin(6, "Priyanka"),
			new Admin(7, "Neha"),
			new Trainer(8, "Srinivas"),
			new Admin(9, "Mythri")
		};
		// print only Trainee Employees 
		for (Emp employee : arr) {
			if (employee instanceof Trainee) {
				System.out.println(employee);
			}
		}
	}
}
