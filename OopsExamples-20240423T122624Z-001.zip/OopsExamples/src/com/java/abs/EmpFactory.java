package com.java.abs;

public class EmpFactory {

	public Emp showInfo(String empType) {
		
	}
}
