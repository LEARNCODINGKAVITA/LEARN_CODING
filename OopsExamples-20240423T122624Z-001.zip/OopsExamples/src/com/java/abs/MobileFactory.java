package com.java.abs;

public class MobileFactory {

	public Mobile showMobileInfo(String type) {
		if (type.equals("Samsung")) {
			return  new Samsung();
		} else if (type.equals("Iphone")) {
			return new IPhone();
		} else if (type.equals("OnePlus")) {
			return new OnePlus();
		}
		return null;
	}
}
