package com.java.abs;

public class Samsung extends Mobile {

	@Override
	void name() {
		System.out.println("Name is Samsung...");
	}

	@Override
	void type() {
		System.out.println("Model I9523");
	}

	@Override
	void price() {
		System.out.println("Price is $482");		
	}

}
