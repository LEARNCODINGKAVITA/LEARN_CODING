package com.java.abs;

abstract class Animal {
	abstract void name();
	abstract void type();
}

class Cow extends Animal {

	@Override
	void name() {
		System.out.println("Name is Cow...");
	}

	@Override
	void type() {
		System.out.println("From Mammals Category...");
	}
	
}
class Crocodile extends Animal {

	@Override
	void name() {
		System.out.println("Name is Crocodile...");
	}

	@Override
	void type() {
		System.out.println("Its a Water Animal...");
	}
	
}

class Lion extends Animal {

	@Override
	void name() {
		System.out.println("Name is Lion...");
	}

	@Override
	void type() {
		System.out.println("Its Wild Animal...");
	}
	
}
public class AbsTest {
	public static void main(String[] args) {
		Animal[] arr = new Animal[] {
			new Cow(), new Crocodile(), new Lion()	
		};
		for (Animal animal : arr) {
			animal.name();
			animal.type();
		}
	}
}
