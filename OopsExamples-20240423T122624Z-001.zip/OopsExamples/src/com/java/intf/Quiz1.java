package com.java.intf;

interface ITest1 {
	default void show() {
		System.out.println("Show from Interface1...");
	}
}

interface ITest2 {
	default void show() {
		System.out.println("Show from Interface2...");
	}
}

interface ITest3 {
	default void show() {
		System.out.println("Show from Interface 3");
	}
}

class Demo implements ITest1, ITest2, ITest3 {

	@Override
	public void show() {
		// TODO Auto-generated method stub
		ITest1.super.show();
		ITest2.super.show();
		ITest3.super.show();
	}
	
}

public class Quiz1 {
	public static void main(String[] args) {
		new Demo().show();
	}
}
