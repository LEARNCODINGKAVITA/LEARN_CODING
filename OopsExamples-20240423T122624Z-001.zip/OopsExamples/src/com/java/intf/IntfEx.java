package com.java.intf;

interface ITraining {
	void name();
	void email();
}

class Khader implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Khader...");
	}

	@Override
	public void email() {
		System.out.println("Email is khader@gmail.com");
	}
	
}
class Kavitha implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Kavitha...");
	}

	@Override
	public void email() {
		System.out.println("Email is kavitha@gmail.com");
	}
	
}
class Baba implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Baba...");
	}

	@Override
	public void email() {
		System.out.println("Email is baba@gmail.com");
	}
	
}
public class IntfEx {
	public static void main(String[] args) {
		ITraining[] arr = new ITraining[] {
			new Baba(), new Kavitha(), new Khader()	
		};
		for (ITraining i : arr) {
			i.name();
			i.email();
		}
	}
}
