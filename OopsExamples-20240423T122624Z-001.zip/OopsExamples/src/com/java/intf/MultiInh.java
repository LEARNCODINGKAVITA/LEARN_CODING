package com.java.intf;

interface IOne {
	void company();
}

interface ITwo {
	void training();
}

class Ramesh implements IOne, ITwo {

	@Override
	public void training() {
		System.out.println("Java FSD Training going on...");
	}

	@Override
	public void company() {
		System.out.println("Company is from Sonix...");
	}
	
}

public class MultiInh {
	public static void main(String[] args) {
		Ramesh obj = new Ramesh();
		obj.company();
		obj.training();
	}
}
