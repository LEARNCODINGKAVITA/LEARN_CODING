package com.java.demo;

public class CaseDemo1 {

	public void show(int choice) {
		switch(choice) {
		case 1 : 
			System.out.println("Hi I am Akhil Kumar...");
			break;
		case 2 : 
			System.out.println("Hi I am BabaSai...");
			break;
		case 3 : 
			System.out.println("Hi I am Chakri...");
			break;
		case 4 : 
			System.out.println("Hi i am Abhilash...");
			break;
		case 5 : 
			System.out.println("Hi I am Parusha Ram...");
			break;
		default : 
			System.out.println("Invalid Choice...");
			break;
		}
	}
	public static void main(String[] args) {
		int choice = 1;
		CaseDemo1 obj = new CaseDemo1();
		obj.show(choice);
	}
}
