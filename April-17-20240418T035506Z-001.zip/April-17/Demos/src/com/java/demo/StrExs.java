package com.java.demo;

public class StrExs {

	public static void main(String[] args) {
		String s1 = "Akhil", s2="Ramu", s3="Baba",s4="Akhil";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
// Write a program to check given no. is perfect number or not
// write a program to display prime numbers from 1 to 1000
// Write a program to display armstrong numbers from 1 to 10000

