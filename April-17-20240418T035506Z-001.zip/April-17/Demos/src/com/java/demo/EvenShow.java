package com.java.demo;

public class EvenShow {

	public void show(int n) {
		int i=0;
		while(i < n) {
			
			System.out.println("Even  " +i);
			i+=2;
		}
	}
	public static void main(String[] args) {
		int n = 20;
		EvenShow obj = new EvenShow();
		obj.show(n);
	}
}
