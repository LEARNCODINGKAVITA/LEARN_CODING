package com.java.demo;

public class ArrayDemo3 {

	public void show() {
		int[] a = new int[] {45,52,11,55,12};
		int[] b = a;
		for (int i : b) {
			System.out.println(i);
		}
	}
	
	public static void main(String[] args) {
		ArrayDemo3 obj = new ArrayDemo3();
		obj.show();
	}
}
