package com.java.demo;

public class ArrayString {

	public void show() {
		String[] names = new String[] {
			"Nikhilesh","Venkata Rao", "Suresh", "Sravani",
			"Khader", "Divya","Chakri"
		};
		for (String s : names) {
			System.out.println(s);
		}
	}
	public static void main(String[] args) {
		ArrayString obj = new ArrayString();
		obj.show();
	}
}
