package com.java.demo;

public class ForLoopExample1 {

	public void show() {
		
		for(int i=0;i<10;i++) {
			System.out.println("Welcome to Java Programming...");
		}
	}
	
	public static void main(String[] args) {
		ForLoopExample1 obj = new ForLoopExample1();
		obj.show();
	}
}
