package com.java.demo;

public class Quiz1 {

	public static void main(String[] args) {
		int[] a = new int[] {4,23,66,31,62,11};
		int[] b = a;
		b[3] = 9;
		System.out.println(a[3] + "" +b[3]);
	}
}
