package com.java.demo;

public class CaseDemo3 {

	public void show(char choice) {
		switch(choice) {
		case 'A' :
			System.out.println("Grade A");
			break;
		case 'B' : 
			System.out.println("Grade B");
			break;
		case 'C' : 
			System.out.println("Grade C");
			break;
		case 'D' : 
			System.out.println("Grade D");
			break;
		case 'E' : 
			System.out.println("Grade E");
		default : 
			System.out.println("Invalid Choice...");
		}
	}
	public static void main(String[] args) {
		char choice='A';
		CaseDemo3 obj = new CaseDemo3();
		obj.show(choice);
	}
}
