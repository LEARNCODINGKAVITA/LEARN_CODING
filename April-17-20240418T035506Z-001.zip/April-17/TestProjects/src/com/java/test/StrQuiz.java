package com.java.test;

public class StrQuiz {
	public static void main(String[] args) {
		String s1="Sudharshan", s2="Bhavanya", s3="Ramesh", s4="Sudharshan";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
