package com.java.test;

public class StrMethods {

	public static void main(String[] args) {
		String str="Welcome to Java Programming...Java Trainer Prasanna...Java Trainer for Sonix";
		System.out.println("Length of String is  " +str.length());
		// indexOf() : Displays the first occurrence of given char, if char not 
		// 				found then it returns -1
		System.out.println("First Occurrence of Word 'Java' is " +str.indexOf("Java"));
		System.out.println("Second Occurrence of char 'Java' is " 
				+str.indexOf("Java",str.indexOf("Java")+1));
		System.out.println("Third Occurrence  " 
				+str.indexOf("Java",str.indexOf("Java",str.indexOf("Java")+1)+1));
		
		// charAt() : Displays char at specific position 
		System.out.println("Char at 5th position  " +str.charAt(5));
		// toUpperCase() : Into upper case
		// toLowerCase() : into lower case
		
		System.out.println("Lower Case String " +str.toLowerCase());
		System.out.println("Upper Case String  " +str.toUpperCase());
		String s1="Akhil", s2="Baba", s3="Akhil";
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s3));
		System.out.println("Part of string  " +str.substring(0, 10));
		System.out.println("Replaced String is  " +str.replace("Java", "J2EE"));
	}
}
