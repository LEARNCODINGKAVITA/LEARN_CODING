package com.java.ex;

public class SbExample {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Welcome to Java...");
		System.out.println(sb);
		sb.append("\n From SonixHub...");
		System.out.println(sb);
	}
}
