package com.java.ex;

class Employ {
	private int empno;
	private String name;
	private double basic;
	
	public Employ() {

	}

	public Employ(int empno, String name, double basic) {
		this.empno = empno;
		this.name = name;
		this.basic = basic;
	}

	@Override
	public String toString() {
		return "Employ [empno=" + empno + ", name=" + name + ", basic=" + basic + "]";
	}

	public int getEmpno() {
		return empno;
	}

	public String getName() {
		return name;
	}

	public double getBasic() {
		return basic;
	}
	
}
public class ReadOnlyEx {
	public static void main(String[] args) {
		Employ employ = new Employ(1, "Jogesh", 88423);
		System.out.println("Employ No   " +employ.getEmpno());
		System.out.println("Employ Name  " +employ.getName());
		System.out.println("Basic   " +employ.getBasic());
	}
}
