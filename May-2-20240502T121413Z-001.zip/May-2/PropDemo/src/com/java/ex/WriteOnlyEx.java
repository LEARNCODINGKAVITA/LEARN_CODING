package com.java.ex;

class Agent {
	
	private int agentId;
	private String agentName;
	private double premium;
	
	public void setAgentId(int agentId) {
		this.agentId = agentId;
	}
	
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	
	public void setPremium(double premium) {
		this.premium = premium;
	}

	@Override
	public String toString() {
		return "Agent [agentId=" + agentId + ", agentName=" + agentName + ", premium=" + premium + "]";
	}
	
}
public class WriteOnlyEx {
	public static void main(String[] args) {
		Agent agent = new Agent();
		agent.setAgentId(1);
		agent.setAgentName("Baba Sai");
		agent.setPremium(88423.22);
		System.out.println(agent);
	}
}
