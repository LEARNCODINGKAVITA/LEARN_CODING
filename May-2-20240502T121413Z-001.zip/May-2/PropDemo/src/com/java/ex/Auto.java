package com.java.ex;

class Customer {
	
	private int customerId;
	private String customerName;
	private double discount;
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", discount=" + discount + "]";
	}
	
}

public class Auto {
	public static void main(String[] args) {
		Customer customer = new Customer();
		customer.setCustomerId(1);
		customer.setCustomerName("Ramesh");
		customer.setDiscount(88235);
		System.out.println("Customer Id  " +customer.getCustomerId());
		System.out.println("Customer Name  " +customer.getCustomerName());
		System.out.println("Discount   " +customer.getDiscount());
	}
}
