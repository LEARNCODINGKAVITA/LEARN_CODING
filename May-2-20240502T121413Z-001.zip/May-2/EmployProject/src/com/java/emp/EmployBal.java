package com.java.emp;

import java.util.List;

public class EmployBal {

	static EmployDao dao = new EmployDaoImpl();
	static StringBuilder sb = new StringBuilder();
	
	public String addEmployBal(Employ employ) throws EmployException {
		if (validateEmploy(employ)==true) {
			return dao.addEmployDao(employ);
		}
		throw new EmployException(sb.toString());
	}
	
	public List<Employ> showEmployBal() {
		return dao.showEmployDao();
	}
	public boolean validateEmploy(Employ employ) {
		boolean flag = true;
		if (employ.getEmpno() <= 0) {
			sb.append("Employ No Cannot be zero or negative...\r\n");
			flag = false;
		}
		if (employ.getName().length() < 5) {
			sb.append("Name Contains Min. 5 characters...\r\n");
			flag = false;
		}
		if (employ.getBasic() < 10000 || employ.getBasic() > 90000) {
			sb.append("Basic Must be Between 10000 and 90000...\r\n");
			flag = false;
		}
		return flag;
	}
}
