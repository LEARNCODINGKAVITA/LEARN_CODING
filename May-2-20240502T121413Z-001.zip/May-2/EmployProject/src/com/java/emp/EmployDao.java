package com.java.emp;

import java.util.List;

public interface EmployDao {

	List<Employ> showEmployDao();
	String addEmployDao(Employ employ);
}
