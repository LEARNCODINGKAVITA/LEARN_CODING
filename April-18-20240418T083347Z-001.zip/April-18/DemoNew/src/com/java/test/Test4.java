package com.java.test;

public class Test4 {

	public static void main(String[] args) {
		Customer customer1 = new Customer();
		customer1.custId = 1;
		customer1.name = "BabaSai";
		customer1.billAmount = 88423.55;
		
		Customer customer2 = new Customer();
		customer2.custId = 2;
		customer2.name = "Sudharshan";
		customer2.billAmount = 90032.55;
		
		System.out.println(customer1);
		System.out.println(customer2);
	}
}
