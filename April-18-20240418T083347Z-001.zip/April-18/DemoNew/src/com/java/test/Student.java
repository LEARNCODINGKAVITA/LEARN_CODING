package com.java.test;

public class Student {

	int sid;
	String sname;
	String city;
	double cgp;
}
