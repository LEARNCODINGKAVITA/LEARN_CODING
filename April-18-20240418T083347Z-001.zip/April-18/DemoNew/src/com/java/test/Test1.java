package com.java.test;

public class Test1 {

	public static void main(String[] args) {
		String s1="Siva Sai";
		String s2="Siva Sai";
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
	}
}
