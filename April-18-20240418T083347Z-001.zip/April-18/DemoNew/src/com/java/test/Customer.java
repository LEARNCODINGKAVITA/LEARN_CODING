package com.java.test;

public class Customer {

	int custId;
	String name;
	double billAmount;
	
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", billAmount=" + billAmount + "]";
	}
	
}
