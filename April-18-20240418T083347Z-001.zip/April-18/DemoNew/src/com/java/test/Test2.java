package com.java.test;

public class Test2 {

	public static void main(String[] args) {
		String s1="Ramesh";
		String s2 = new String("Ramesh");
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
	}
}
