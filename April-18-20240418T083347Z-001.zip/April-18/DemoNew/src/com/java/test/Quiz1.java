package com.java.test;

public class Quiz1 {

	public static void main(String[] args) {
		
	}
}
