package com.java.day1;

public class Calcuation {

	public static void main(String[] args) {
		int a, b, c;
		a = 5;
		b = 7;
		c = a + b;
		System.out.println("Sum is  " +c);
		c = a - b;
		System.out.println("Sub is  " +c);
		c = a * b;
		System.out.println("Mult is  " +c);
	}
}
