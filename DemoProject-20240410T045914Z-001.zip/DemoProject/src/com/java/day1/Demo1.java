package com.java.day1;

public class Demo1 {

	public static void main(String[] args) {
		String s1="Java";
		String s2 ="Sonix";
		System.out.println("String 1  " +s1);
		System.out.println("String 2  " +s2);
	}
}
