package com.java.day1;

public class Quiz3 {

	public static void main(String[] args) {
		int x = 12;
		int y = ++x;
		System.out.println(y);
	}
}
