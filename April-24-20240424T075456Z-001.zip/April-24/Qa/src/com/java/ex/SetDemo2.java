package com.java.ex;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetDemo2 {
	public static void main(String[] args) {
		Set names = new LinkedHashSet();
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		System.out.println("Names are ");
		for (Object object : names) {
			System.out.println(object);
		}
	}
}
