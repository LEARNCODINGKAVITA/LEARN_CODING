package com.java.ex;

import java.util.HashSet;
import java.util.Set;

public class Quiz1 {

	public static void main(String[] args) {
		Set employs= new HashSet();
		employs.add(new Employ(1, "Sudharshan", 77344));
		employs.add(new Employ(2, "Bhavanya", 90042));
		employs.add(new Employ(3, "Naresh", 90321));
		employs.add(new Employ(4, "Shilpa", 88311));
		employs.add(new Employ(5, "Chakri", 89922));
		employs.add(new Employ(6, "Shekhar", 81442));
		employs.add(new Employ(1, "Sudharshan", 77344));
		employs.add(new Employ(2, "Bhavanya", 90042));
		employs.add(new Employ(3, "Naresh", 90321));
		employs.add(new Employ(4, "Shilpa", 88311));
		employs.add(new Employ(5, "Chakri", 89922));
		employs.add(new Employ(1, "Sudharshan", 77344));
		employs.add(new Employ(2, "Bhavanya", 90042));
		employs.add(new Employ(3, "Naresh", 90321));
		employs.add(new Employ(4, "Shilpa", 88311));
		employs.add(new Employ(5, "Chakri", 89922));
		employs.add(new Employ(2, "Bhavanya", 90042));
		employs.add(new Employ(3, "Naresh", 90321));
		employs.add(new Employ(4, "Shilpa", 88311));
		employs.add(new Employ(5, "Chakri", 89922));
		employs.add(new Employ(6, "Shekhar", 81442));
		employs.add(new Employ(2, "Bhavanya", 90042));
		employs.add(new Employ(3, "Naresh", 90321));
		employs.add(new Employ(4, "Shilpa", 88311));
		employs.add(new Employ(5, "Chakri", 89922));
		employs.add(new Employ(6, "Shekhar", 81442));

		for (Object object : employs) {
			Employ employ = (Employ)object;
			System.out.println(employ);
		}
	}
}
