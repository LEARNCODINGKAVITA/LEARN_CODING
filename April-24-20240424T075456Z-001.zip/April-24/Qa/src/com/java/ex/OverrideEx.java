package com.java.ex;

class Training {
	void name() {
		System.out.println("Training Info...");
	}
}

class Mohammad extends Training {
	void name() {
		System.out.println("Hi I am Mohammad...");
	}
}

class Sravani extends Training {
	void name() {
		System.out.println("Hi I am Sravani...");
	}
}

class Abhi extends Training {
	void name() {
		System.out.println("Hi I am Abhi...");
	}
}


public class OverrideEx {
	public static void main(String[] args) {
		Training[] arr = new Training[] {
			new Mohammad(), new Sravani(), new Abhi()	
		};
		for (Training t : arr) {
			t.name();
		}
	}
}
