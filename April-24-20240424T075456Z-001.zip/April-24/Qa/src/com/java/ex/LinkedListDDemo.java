package com.java.ex;

import java.util.LinkedList;

public class LinkedListDDemo {

	public static void main(String[] args) {
		LinkedList linkedList = new LinkedList();
		linkedList.add("Ramesh");
		linkedList.add("Jogesh");
		linkedList.add("Baba");
		linkedList.add("Sudharshan");
		linkedList.add("Abhi");
		linkedList.addFirst("Bhavana");
		linkedList.addLast("Venkat");
		System.out.println(linkedList);
	}
}
