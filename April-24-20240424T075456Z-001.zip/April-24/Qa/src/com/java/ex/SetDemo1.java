package com.java.ex;

import java.util.HashSet;
import java.util.Set;

public class SetDemo1 {

	public static void main(String[] args) {
		Set names = new HashSet();
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		System.out.println("Names are ");
		for (Object object : names) {
			System.out.println(object);
		}
	}
}
