package com.java.ex;

import java.util.ArrayList;
import java.util.List;

public class ListExample2 {

	public static void main(String[] args) {
		List employs = new ArrayList();
		employs.add(new Employ(1, "Sudharshan", 77344));
		employs.add(new Employ(2, "Bhavanya", 90042));
		employs.add(new Employ(3, "Naresh", 90321));
		employs.add(new Employ(4, "Shilpa", 88311));
		employs.add(new Employ(5, "Chakri", 89922));
		employs.add(new Employ(6, "Shekhar", 81442));
		System.out.println("Employ List is  ");
		for (Object object : employs) {
			Employ employ = (Employ)object;
			System.out.println(employ);
		}
	}
}
