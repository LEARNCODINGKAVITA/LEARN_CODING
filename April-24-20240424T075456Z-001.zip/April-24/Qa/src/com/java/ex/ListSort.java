package com.java.ex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListSort {

	public static void main(String[] args) {
		List names = new ArrayList();
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		System.out.println("List of values");
		for (Object object : names) {
			System.out.println(object);
		}
		Collections.sort(names);
		System.out.println("Sorted Names  ");
		for (Object object : names) {
			System.out.println(object);
		}
	}
}
