package com.java.ex;

import java.util.ArrayList;
import java.util.List;

public class ListExample1 {

	public static void main(String[] args) {
		List names = new ArrayList();
		names.add("Ramesh");
		names.add("Jogesh");
		names.add("Baba");
		names.add("Sudharshan");
		names.add("Abhi");
		System.out.println("Names are");
		for (Object object : names) {
			System.out.println(object);
		}
		names.add(2, "Krishnaveni");
		System.out.println("Names after Insert Operation");
		for (Object object : names) {
			System.out.println(object);
		}
		names.set(3, "Sai Kumar");
		System.out.println("Names after Update");
		for (Object object : names) {
			System.out.println(object);
		}
		names.remove("Abhi");
		System.out.println("Names after Remove Operation  ");
		for (Object object : names) {
			System.out.println(object);
		}
	}
}
