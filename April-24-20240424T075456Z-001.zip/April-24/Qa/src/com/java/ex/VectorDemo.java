package com.java.ex;

import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		Vector v = new Vector(3, 2);
		System.out.println("Size  " +v.size());
		System.out.println("Capacity  " +v.capacity());
		v.add(12);
		v.add(13);
		System.out.println("Size  " +v.size());
		System.out.println("Capacity  " +v.capacity());
		v.add(64);
		System.out.println("Size  " +v.size());
		System.out.println("Capacity  " +v.capacity());
		v.add(52);
		System.out.println("Size  " +v.size());
		System.out.println("Capacity  " +v.capacity());
	}
}
