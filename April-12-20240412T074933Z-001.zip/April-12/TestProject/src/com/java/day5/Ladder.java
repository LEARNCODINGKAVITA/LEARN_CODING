package com.java.day5;

public class Ladder {

	public void check(int choice) {
		if (choice==1) {
			System.out.println("Hi I am Manohar...");
		} else if (choice == 2) {
			System.out.println("Hi I am Kavitha Kumari...");
		} else if (choice == 3) {
			System.out.println("Hi I am Rakesh Reddy");
		} else if (choice == 4) {
			System.out.println("Hi I am Hanumanth...");
		} else if (choice == 5) {
			System.out.println("Hi I am Vijay Kumar...");
		} else {
			System.out.println("Unknown Name...");
		}
	}
	public static void main(String[] args) {
		int choice = 3;
	}
}
