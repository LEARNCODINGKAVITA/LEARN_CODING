package com.java.day5;

public class CurrentBill {

	public void billing(int units) {
		double billAmount = 0;
		double rate = 0;
		if (units <= 90) {
			rate = 1;
			billAmount = units * rate;
		}
		if (units > 90) {
			billAmount = 90 * 1;
			rate = 1.5;
			if (units - 150 >= 0) {
				billAmount += (60 * rate); 
			} else {
				billAmount += (units - 90) * rate;
			}
		}
		
		if (units > 150) {
			rate = 2;
			if (units - 200 >= 0) {
				billAmount += (50 * rate);
			} else {
				billAmount += (units - 150) * rate;
			}
		}
		
		if (units > 200) {
			rate = 2.5;
			if (units - 250 >= 0) {
				billAmount += (50 * rate);
			} else {
				billAmount += (units - 200) * rate;
			}
		}
		
		if (units > 250) {
			rate = 3;
			billAmount += (units - 250) *rate;
		}

		System.out.println("Total Bill Amount  " +billAmount);
	}
	public static void main(String[] args) {
		int units = 250;
		CurrentBill currentBill = new CurrentBill();
		currentBill.billing(units);
	}
}
